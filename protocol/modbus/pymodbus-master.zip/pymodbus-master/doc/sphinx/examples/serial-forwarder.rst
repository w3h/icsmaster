==================================================
Synchronous Serial Forwarder
==================================================

.. literalinclude:: ../../../examples/contrib/serial-forwarder.py

