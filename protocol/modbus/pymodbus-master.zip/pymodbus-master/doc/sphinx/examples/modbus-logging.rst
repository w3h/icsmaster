==================================================
Modbus Logging Example
==================================================

.. literalinclude:: ../../../examples/common/modbus-logging.py

