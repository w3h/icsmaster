==================================================
Synchronous Client Performance Check
==================================================

Below is a quick example of how to test the performance of a tcp modbus
device using the synchronous tcp client.  If you do not have a device
to test with, feel free to run a pymodbus server instance or start
the reference tester in the tools directory.

.. literalinclude:: ../../../examples/common/performance.py

