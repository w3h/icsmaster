==================================================
Synchronous Server Example
==================================================

.. literalinclude:: ../../../examples/common/synchronous-server.py

