

class IncorrectState(Exception):
    pass
