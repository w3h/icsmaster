c-scad
======

C-SCAD : ClearSCADA Web-X Client Penetration Testing Tool !

C-SCAD is an information gathering and penetration testing tool written to assess the security issues present in the Web-X (Internet Explorer-based web interface) client used to interact with the ClearSCADA server. Web-X client is hosted on the embedded web server which is shipped as a part of complete ClearSCADA architecture. Primarily, the Web-X client is restricted to perform any configuration changes but it can reveal potential information about the ClearSCADA server and associated components. Insecure deployments of WEB-X client can reveal potential information about the various functions such as alarm pages, SQL lists, and diagnostic checks including various reports.
